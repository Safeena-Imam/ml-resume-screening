import os
import pickle
import re
import streamlit as st
from pypdf import PdfReader  # PDF extraction
import docx  # Word file extraction
import pandas as pd

# Load models
tfidf = pickle.load(open("tfidf_vectorizer.pkl", "rb"))
model = pickle.load(open("logistic_regression_model.pkl", "rb"))

# Category mapping
category_mapping = {
    15: "Java Developer",
    23: "Testing",
    8: "DevOps Engineer",
    20: "Python Developer",
    24: "Web Designing",
    12: "HR",
    13: "Hadoop",
    3: "Blockchain",
    10: "ETL Developer",
    18: "Operations Manager",
    6: "Data Science",
    22: "Sales",
    16: "Mechanical Engineer",
    1: "Arts",
    7: "Database",
    11: "Electrical Engineering",
    14: "Health and fitness",
    19: "PMO",
    4: "Business Analyst",
    9: "DotNet Developer",
    2: "Automation Testing",
    17: "Network Security Engineer",
    21: "SAP Developer",
    5: "Civil Engineer",
    0: "Advocate",
}

def clean_resume(resume_text):
    # Remove URLs
    resume_text  = re.sub(r'https?://\S+|www\.\S+', '', resume_text) 
    
    # Remove emails
    resume_text = re.sub(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b', '', resume_text)
    
    # Remove special characters (keep only letters and spaces)
    resume_text  = re.sub(r'[^\w\s]', '',resume_text)
    
     # Remove extra spaces
    resume_text = re.sub(r'\s+', ' ', resume_text) 
    
    # Remove digits
    resume_text = re.sub(r'\d+', '', resume_text)  
    
    # Remove non-ASCII characters 
    resume_text = re.sub(r'[^\x00-\x7f]', ' ', resume_text)  
    
     # Remove punctuation
    resume_text = re.sub(r'[^\w\s]', ' ', resume_text) 
    return resume_text

def handle_file_upload(uploaded_file):
    # Function to handle file upload and extract text
    if uploaded_file.type == "application/pdf":
        # Extract text from PDF
        pdf_reader = PdfReader(uploaded_file)
        resume_text = ""
        for page in pdf_reader.pages:
            resume_text += page.extract_text()
    elif uploaded_file.type == "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
        # Extract text from DOCX
        doc = docx.Document(uploaded_file)
        resume_text = "\n".join([para.text for para in doc.paragraphs])
    else:
        # Extract text from TXT
        resume_text = uploaded_file.read().decode('utf-8')
    return resume_text

def categorize_resumes(uploaded_files, output_directory):
    if not os.path.exists(output_directory):
        os.makedirs(output_directory)

    results = []

    for uploaded_file in uploaded_files:
        # Extract text from the uploaded file
        resume_text = handle_file_upload(uploaded_file)
        cleaned_resume = clean_resume(resume_text)

        # Transform the resume text using the loaded TF-IDF vectorizer
        input_features = tfidf.transform([cleaned_resume])

        # Predict the category of the resume
        prediction_id = model.predict(input_features)[0]
        category_name = category_mapping.get(prediction_id, "Unknown")

        # Save the file in the corresponding category folder
        category_folder = os.path.join(output_directory, category_name)

        if not os.path.exists(category_folder):
            os.makedirs(category_folder)

        target_path = os.path.join(category_folder, uploaded_file.name)
        with open(target_path, "wb") as f:
            f.write(uploaded_file.getbuffer())

        # Add the result to the list
        results.append({'filename': uploaded_file.name, 'category': category_name})

    results_df = pd.DataFrame(results)
    return results_df

def main():
    st.set_page_config(page_title="Resume Category Prediction", page_icon="📄", layout="wide")
    st.title("Resume Categorizer with Python & Machine Learning")
    st.markdown("Upload resumes in PDF, DOCX, or TXT format to predict job categories.")

    # File upload section
    uploaded_files = st.file_uploader("Choose PDF, DOCX, wordfile or TXT files", type=["pdf", "docx", "txt" ,"wordfile"], accept_multiple_files=True)
    output_directory = st.text_input("Output Directory", "categorized_resumes")

    # Display file upload section
    st.markdown("### Instructions:")
    st.markdown("1. Upload multiple resumes.")
    st.markdown("2. Click 'Categorize Resumes' to process them.")
    st.markdown("3. Download the results as a CSV file.")

    if st.button("Categorize Resumes"):
        if uploaded_files and output_directory:
            # Categorize the uploaded resumes
            results_df = categorize_resumes(uploaded_files, output_directory)

            # Display results as DataFrame
            st.write("### Categorized Resumes:")
            st.write(results_df)

            # Provide a download link for the results
            results_csv = results_df.to_csv(index=False).encode('utf-8')
            st.download_button(
                label="Download results as CSV",
                data=results_csv,
                file_name="categorized_resumes.csv",
                mime="text/csv"
            )

            st.success("Resumes categorization and processing completed.")
        else:
            st.error("Please upload files and specify the output directory.")

if __name__ == "__main__":
    main()
